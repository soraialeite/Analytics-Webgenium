<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<style type="text/css"><!--
        body {
           font-size: 11px;
        }
        body, td, th {
           font-family: Arial,Helvetica,sans-serif;
           font-size: 11px;
           font: 11px arial;
        }
--></style>
<div style="background-color: #e2e8df; width: 100%; font-family: Tahoma,Geneva,Kalimati,sans-serif; color: #8a8a8a; text-align: center;">
<table style="text-align:left;margin:auto;" width="750" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td width="37"></td>
<td style="background-color:#fbfbf7" valign="top" width="496">
<table width="100%" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td colspan="2" height="20"></td>
</tr>
<tr>
<td width="20"></td>
<td style="background-color:#F9F7D3">
<h1><?=JText::_('Statistics')?></h1></td>
<td width="20"></td>
</tr>
<tr>
<td colspan="5">
<table width="100%">
<tbody>
<tr>
<td style="text-align: center;"><span><strong><?=$this->conteudo_email?></strong></span></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
<td width="27"></td>
</tr>
<tr style="line-height: 0px;">
<td style="line-height: 0px;" colspan="3"></td>
</tr>
<tr>
<td colspan="3" style="padding:20px 0px;font-size:10px;color:#000000;margin:auto;text-align:center;"><br /></td>
</tr>
</tbody>
</table>
</div>